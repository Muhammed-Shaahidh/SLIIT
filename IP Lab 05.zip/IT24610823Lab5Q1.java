/*
 Write a Java program to read three different integers from the keyboard and compute
 the smallest and largest of these numbers
 */

import java.util.Scanner;

public class IT24610823Lab5Q1{
public static void main(String[]args){

int num1, num2, num3;

Scanner input=new Scanner(System.in);

System.out.print("Enter the first integer:");
num1=input.nextInt();

System.out.print("Enter the second integer:");
num2= input.nextInt();

System.out.print("Enter the third integer:");
num3= input.nextInt();


System.out.println("User entered numbers are:" +num1+ " "+ num2+ " "+num3);

int Smallest= num1;

if (num2< num1){
Smallest= num2;
}

if (num3< num1){
Smallest= num3;
}

int Largest= num1;

if (num2> num1){
Largest= num2;
}

if (num3> num1){
Largest= num3;
}

System.out.println("The Smallest number is:" +Smallest);
System.out.println("The Largest number is:" +Largest);


}

}


