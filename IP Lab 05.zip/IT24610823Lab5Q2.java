/*
A credit card company has a promotion for existing customers to introduce new mem
bers. Prizes are given to the customers depending on the number of new members they
 introduce. For example, if a customer has introduced 3 people, then he/she is entitled to
 a: Bag.
 */

import java.util.Scanner;

public class IT24610823Lab5Q2{
public static void main(String[]args){

int new_mem;
String Prize;

Scanner input= new Scanner(System.in);

System.out.print("Enter the number of new members introduced:");
new_mem= input.nextInt();

if (new_mem<0){
System.out.println("Invalid input");
return;
}

switch (new_mem){

case 0:
Prize= "No prize";
break;

case 1:
Prize= ("Pen");
break;

case 2:
Prize= ("Umbrella");
break;

case 3:
Prize= ("Bag");
break;

case 4:
Prize= ("Travelling Chair");
break;


default:
Prize= ("Headphone");
}

System.out.println("Prize ia a : " +Prize);


}

}