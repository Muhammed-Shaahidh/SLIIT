/*
 Ransiri Resort offers discount for full board reservations during the month of December
 as shown below. Discount is given only for the reservations done for more than 3 days.
 Room charges per day is Rs 48,000.00.

 No of Days Reserved        Discount Rate (%)
 < 3 days                     No discount
 3– 4 days                        10
 5 or more                        20

 Write a Java program to enter the start date (day) and end date (day) of the reserva
tion and find out the number of days reserved and the total amount to be paid. Use
 CONSTANTS to declare fixed values.
 
 After the start date and end dates are entered, validate the below conditions. If the
 conditions fail, display error messages and exit from the program.
 Validation 1– Start date and end date cannot be less than 1 or greater than 31
 Validation 2– Start date should be less than the end date
 */

import java.util.Scanner;

public class IT24610823Lab5Q3{

public static final double Room_charge_per_day= 48000;
public static final int discount_1= 10;
public static final int discount_2= 20;

public static void main(String[] args){

Scanner input=  new Scanner(System.in);

System.out.print("Enter Start Date(1-31): ");
int Start_date= input.nextInt();

System.out.print("Enter End Date(1-31): ");
int End_date= input.nextInt();

if (Start_date>31 || Start_date<=0 ||End_date>31 || End_date<0){
System.out.println("Error: Days must be between 1 and 31");
return;
}

if (Start_date>= End_date){
System.out.println("Error: Start date must be less than End date");
return;
}

int NumOfDays= End_date - Start_date;

double Amount= NumOfDays * Room_charge_per_day;

int DiscountPercentage= 0;

if (NumOfDays>=3 && NumOfDays<=4){
DiscountPercentage= discount_1;
}

else if (NumOfDays>=5){
DiscountPercentage= discount_2;
}


double DiscountAmount= (Amount * DiscountPercentage) / 100.0;
double TotalAmount= Amount- DiscountAmount;

System.out.println("Room Charge Per Day: Rs." +Room_charge_per_day);
System.out.println("Number Of Days Reserved: " +NumOfDays);
System.out.println("Total Amount to be paid: " +TotalAmount);

}

}

