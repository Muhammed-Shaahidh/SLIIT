/*
 Write a Java method called circleArea() that take the radius of a circle as an argu
ment/parameter, then calculate area and return the area.

 In the Main Method, read the radius value as an user input via keyboard, then call the
 circleArea() method to display the result.
 */

import java.util.Scanner;

public class IT24610823Lab9Q2{
   
public static double circleArea(int rad){
    return Math.PI * Math.pow(rad, 2);
}

public static void main(String[]args){

    Scanner input= new Scanner(System.in);

    System.out.print("Enter the radius of the circle: ");
    int rad= input.nextInt();

    double area= circleArea(rad);

    System.out.println("The area of the circle with radius " +rad+ ": " +area);
    
}

}