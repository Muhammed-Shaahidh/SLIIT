/*
 Write three Java methods do the following
    • add()– add two integers pass as parameters and return the result
    • multiply()– multiply two integers pass as parameters and return the result
    • square()– receive an integer as a parameter and return the result after multiplying
      the number by itself.
      
 Use the above methods in the Main Method to calculate the result of the following
 mathematical expressions:
    i. (3∗4 + 5∗7)²
    ii. (4+7)² + (8+3)²
 */

public class IT24610823Lab9Q3{

  public static int add(int a, int b){
    return a+ b;
  }
public static int multiply(int a, int b){
    return a* b;
}

public static int  square(int a){
    return a * a;
}
    public static void main(String[]args){

int sq1= square(add(multiply(3, 4),multiply(5, 7)));

int a2 = add(4, 7);
int sq2= square(a2);
int a3= add(8, 3);
int sq3= square(a3);
int a4= add(sq2, sq3);

System.out.println("Result of (3 * 4 + 5 * 7)² : " + sq1);
System.out.println("Result of (4 + 7)² + (8 + 3)² : " +a4);

    }
}