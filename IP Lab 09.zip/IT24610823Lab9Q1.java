/*
 The ‘Quadratic Equation’ is given below.
 
            X = -b ± √(b² - 4ac) / 2a
 
 Write a Java program to input any three values for a, b, c and to calculate the x value.
 Hint: Use pow() and sqrt() methods in Java Math class.
 */

import java.util.Scanner;

public class IT24610823Lab9Q1{
    public static void main(String[]args){

Scanner input= new Scanner(System.in);

int value[]= new int[3];

for(int i= 0; i<= 2; i++){
char grade= (char) ('a' + i);

System.out.print("Enter value " +grade+ ": ");
value[i]= input.nextInt();
}

double sq= Math.sqrt(Math.pow(value[1], 2) - 4*(value[0]* value[2]));

double rt1= (-value[1] + sq)/ (2* value[0]);
double rt2= (-value[1] - sq)/ (2* value[0]);

System.out.println("Roots are real and different :");

System.out.println("Root 1: " +rt1);
System.out.println("Root 2: " +rt2);

}
}