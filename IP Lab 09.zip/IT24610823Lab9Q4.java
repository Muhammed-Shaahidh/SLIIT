/*
Write a Java program to calculate the Final Mark and Grade of 5 students for a subject.

 a) Write a Java method called calcFinalMark() to calculate the final mark of the
 subject. When calculating the final mark, 30% is taken from the assignment mark
 and 70% is taken from the exam paper mark.
 Method should return the final mark

 b) Write a method called findGrades() to return the grade obtained for the given
 final mark. Grades are calculated as follows:

       Final Mark           Grade
       mark >= 75             A
       60 <= mark < 75        B
       50 <= mark < 60        C
       mark < 50              F

 c) Write a method called printDetails() to print the Name, Final Mark and Grade
 of a student.
 Your output should be as follows:

        Name        Final Mark      Grade
        .....       .........       .....
        .....       .........       .....
        .....       .........       .....

 d) In your Main Method, ask the user to enter the Name, Assignment Mark (out of
 100) and the Exam Paper Mark (out of 100) of the 5 students from the keyboard.
 Display the Name, Final Mark and Grade of a student.
 
 Hint: Use the methods written in section b) and c)
 */

import java.util.Scanner;

public class IT24610823Lab9Q4{
    
    public static double calcFinalMark(double am, double pm){
        return (am * (0.3)) + (pm * (0.7));
    
    }
    public static void main(String[]args){

Scanner input= new Scanner(System.in);

String name[] = new String[5];
double A_mark[] = new double[5];
double P_mark[] = new double[5];
double F_mark[] = new double[5];
char grade[] = new char[5];

       for(int i= 0; i<= 4; i++){

        System.out.println("Enter Name of Student " + (i + 1)+": ");
        name[i] = input.next();
   
         System.out.println("Enter Assignment Mark (out of 100) for " +name[i]+ ": ");
        A_mark[i] = input.nextInt();

         System.out.println("Enter Exam Paper Mark (out of 100) for " +name[i]+ ": ");
        P_mark[i] = input.nextInt();
   
   }
    for(int i= 0; i<= 4; i++){
        
    F_mark[i]= calcFinalMark(A_mark[i], P_mark[i]);
  
       if(F_mark[i] >= 75){
        grade[i]= 'A';
       }
       else if(F_mark[i] >= 60){
        grade[i] = 'B';
       }
       else if(F_mark[i] >= 50){
        grade[i] = 'C';
       }
       else {
        grade[i] = 'F';
       }

    }

     System.out.println("Name \t Final Mark \t Grade");
     for(int i = 0; i<=4; i++){
        System.out.printf("%s\t%.2f\t\t%c%n" , name[i], F_mark[i], grade[i]);
     }
      
       }
    
   
    }