CREATE TABLE Student(

sid VARCHAR(10) PRIMARY KEY,
sname VARCHAR(25) NOT NULL,
address VARCHAR(100),
dob DATE,
nic VARCHAR(10) UNIQUE NOT NULL,
cid VARCHAR(10),
FOREIGN KEY (cid) REFERENCES Course(cid) 

)

CREATE TABLE Offers(

cid VARCHAR(10),
FOREIGN KEY (cid) REFERENCES Course(cid),
Mcode VARCHAR(10),
FOREIGN KEY (Mcode) REFERENCES Module(Mcode),
Accadamic_Year VARCHAR(10),
Semester INT,
PRIMARY KEY(cid, Mcode)

)

CREATE TABLE Module(

Mcode VARCHAR(10) PRIMARY KEY,
Mname VARCHAR(50),
M_Description VARCHAR(150),
NoOfCredits INT NOT NULL

)

CREATE TABLE Course(

cid VARCHAR(10) PRIMARY KEY,
Cname VARCHAR(50) NOT NULL,
C_Description VARCHAR(150),
C_Fee FLOAT(10) CHECK (C_Fee >= 0)

)

DROP TABLE IF EXISTS Student
DROP TABLE IF EXISTS Course
DROP TABLE IF EXISTS Module
DROP TABLE IF EXISTS Offers

SELECT * FROM Student
SELECT * FROM Offers
SELECT * FROM Module
SELECT * FROM Course

ALTER TABLE Student 
ADD CONSTRAINT chk_nic 
CHECK (nic LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][Vv]')

ALTER TABLE Module
ADD CONSTRAINT chk_credits
CHECK (NoOfCredits IN (1, 2, 3, 4))

