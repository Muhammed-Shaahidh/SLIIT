package com.lab04;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.sql.*;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    // Student Table
    @FXML private TextField txtSID;
    @FXML private TextField txtSname;
    @FXML private TextField txtAddress;
    @FXML private TextField txtdob;
    @FXML private TextField txtNIC;
    @FXML private TextField txtS_CID;

    // Course Table
    @FXML private TextField txtCID;
    @FXML private TextField txtCname;
    @FXML private TextField txtC_Description;
    @FXML private TextField txtC_fee;

    // Module Table
    @FXML private TextField txtMcode;
    @FXML private TextField txtMname;
    @FXML private TextField txtM_Description;
    @FXML private TextField txtNoOfCredits;

    // Offers Table
    @FXML private TextField txtO_CID;
    @FXML private TextField txtO_Mcode;
    @FXML private TextField txtAcademic_year;
    @FXML private TextField txtSemster;

    @FXML private Label statusLabel;

    private final String url = "jdbc:sqlserver://localhost:1433;databaseName=DDD;encrypt=false";
    private final String user = "sa";
    private final String password = "123";

    // ---------- INSERT STUDENT ----------
    @FXML
    private void handleInsertStudent() {
        String sql = "INSERT INTO Student (sid, sname, address, dob, nic, cid) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, txtSID.getText());
            stmt.setString(2, txtSname.getText());
            stmt.setString(3, txtAddress.getText());
            stmt.setString(4, txtdob.getText());
            stmt.setString(5, txtNIC.getText());
            stmt.setString(6, txtS_CID.getText());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                statusLabel.setText("Student inserted successfully!");
                clearStudentForm();
                showAlert("Success", "Student data submitted successfully!");
            }

        } catch (SQLException e) {
            statusLabel.setText("Error: " + e.getMessage());
            showAlert("Error", e.getMessage());
        }
    }

    @FXML
    private void handleSearchStudent() {
        String sql = "SELECT * FROM Student WHERE sid = ?";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, txtSID.getText());  // search by SID
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                txtSname.setText(rs.getString("sname"));
                txtAddress.setText(rs.getString("Address"));
                txtdob.setText(rs.getString("dob"));
                txtNIC.setText(rs.getString("NIC"));
                txtS_CID.setText(rs.getString("CID"));
                statusLabel.setText("Student found. You can update the Address now.");
            } else {
                statusLabel.setText("No student found with SID: " + txtSID.getText());
            }

        } catch (SQLException e) {
            statusLabel.setText("Error: " + e.getMessage());
            showAlert("Error", e.getMessage());
        }
    }
    // ---------- UPDATE STUDENT ADDRESS ----------
    @FXML
    private void handleUpdateStudentAddress() {
        String sql = "UPDATE Student SET address = ? WHERE sid = ?";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, txtAddress.getText()); // new address
            stmt.setString(2, txtSID.getText());     // identify student by SID

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                statusLabel.setText("Student address updated successfully!");
                showAlert("Success", "Student address updated!");
            } else {
                statusLabel.setText("No student found with given SID!");
                showAlert("Not Found", "No student found with SID: " + txtSID.getText());
            }

        } catch (SQLException e) {
            statusLabel.setText("Error: " + e.getMessage());
            showAlert("Error", e.getMessage());
        }
    }



    // ---------- INSERT COURSE ----------
    @FXML
    private void handleInsertCourse() {
        String sql = "INSERT INTO Course (cid, Cname, C_Description, C_Fee) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, txtCID.getText());
            stmt.setString(2, txtCname.getText());
            stmt.setString(3, txtC_Description.getText());
            stmt.setDouble(4, Double.parseDouble(txtC_fee.getText()));

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                statusLabel.setText("Course inserted successfully!");
                clearCourseForm();
                showAlert("Success", "Course data submitted successfully!");
            }

        } catch (SQLException | NumberFormatException e) {
            statusLabel.setText("Error: " + e.getMessage());
            showAlert("Error", e.getMessage());
        }
    }

    // ---------- INSERT MODULE ----------
    @FXML
    private void handleInsertModule() {
        String sql = "INSERT INTO Module (Mcode, Mname, M_Description, NoOfCredits) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, txtMcode.getText());
            stmt.setString(2, txtMname.getText());
            stmt.setString(3, txtM_Description.getText());
            stmt.setInt(4, Integer.parseInt(txtNoOfCredits.getText()));

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                statusLabel.setText("Module inserted successfully!");
                clearModuleForm();
                showAlert("Success", "Module data submitted successfully!");
            }

        } catch (SQLException | NumberFormatException e) {
            statusLabel.setText("Error: " + e.getMessage());
            showAlert("Error", e.getMessage());
        }
    }
    @FXML
    private void handleSearchModule() {
        String sql = "SELECT * FROM Module WHERE Mcode = ?";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, txtMcode.getText());
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                txtMname.setText(rs.getString("Mname"));
                txtM_Description.setText(rs.getString("M_Description"));
                txtNoOfCredits.setText(String.valueOf(rs.getInt("NoOfCredits")));
                statusLabel.setText("Module found. You can delete the Module Name now.");
            } else {
                statusLabel.setText("No module found with Mcode: " + txtMcode.getText());
            }

        } catch (SQLException e) {
            statusLabel.setText("Error: " + e.getMessage());
            showAlert("Error", e.getMessage());
        }
    }
    // ---------- DELETE MODULE NAME (SET TO NULL) ----------
    @FXML
    private void handleDeleteModuleName() {
        String sql = "UPDATE Module SET Mname = NULL WHERE Mcode = ?";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, txtMcode.getText());  // which module to clear

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                statusLabel.setText("Module name removed successfully!");
                showAlert("Success", "Module name removed (record kept).");
            } else {
                statusLabel.setText("No module found with given Mcode!");
                showAlert("Not Found", "No module found with Mcode: " + txtMcode.getText());
            }

        } catch (SQLException e) {
            statusLabel.setText("Error: " + e.getMessage());
            showAlert("Error", e.getMessage());
        }
    }


    // ---------- INSERT OFFER ----------
    @FXML
    private void handleInsertOffer() {
        String sql = "INSERT INTO Offers (cid, Mcode, Accadamic_Year, Semester) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, txtO_CID.getText());
            stmt.setString(2, txtO_Mcode.getText());
            stmt.setString(3, txtAcademic_year.getText());
            stmt.setInt(4, Integer.parseInt(txtSemster.getText()));

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                statusLabel.setText("Offer inserted successfully!");
                clearOfferForm();
                showAlert("Success", "Offer data submitted successfully!");
            }

        } catch (SQLException | NumberFormatException e) {
            statusLabel.setText("Error: " + e.getMessage());
            showAlert("Error", e.getMessage());
        }
    }

    // ---------- CLEAR FORM METHODS ----------
    private void clearStudentForm() {
        txtSID.clear();
        txtSname.clear();
        txtAddress.clear();
        txtdob.clear();
        txtNIC.clear();
        txtS_CID.clear();
    }

    private void clearCourseForm() {
        txtCID.clear();
        txtCname.clear();
        txtC_Description.clear();
        txtC_fee.clear();
    }

    private void clearModuleForm() {
        txtMcode.clear();
        txtMname.clear();
        txtM_Description.clear();
        txtNoOfCredits.clear();
    }

    private void clearOfferForm() {
        txtO_CID.clear();
        txtO_Mcode.clear();
        txtAcademic_year.clear();
        txtSemster.clear();
    }






    // ---------- HELPER ALERT ----------
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}