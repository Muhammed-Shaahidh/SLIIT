package com.lab04;

import java.sql.*;

public class MSSQL_Connect {

    public static void main(String[] args) {

        // Database connection info
        String url = "jdbc:sqlserver://localhost:1433;databaseName=DDD;encrypt=false";
        String user = "sa";
        String password = "123";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            System.out.println("✅ Connected to SQL Server!\n");

            // ---------- Student Table ----------
            System.out.println("---- Student Table ----");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM Student")) {

                while (rs.next()) {
                    System.out.println(
                            "SID: " + rs.getString("sid") +
                                    ", Name: " + rs.getString("sname") +
                                    ", Address: " + rs.getString("address") +
                                    ", DOB: " + rs.getString("dob") +
                                    ", NIC: " + rs.getString("nic") +
                                    ", CID: " + rs.getString("cid")
                    );
                }
            }

            // ---------- Course Table ----------
            System.out.println("\n---- Course Table ----");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM Course")) {

                while (rs.next()) {
                    System.out.println(
                            "CID: " + rs.getString("cid") +
                                    ", Name: " + rs.getString("Cname") +
                                    ", Description: " + rs.getString("C_Description") +
                                    ", Fee: " + rs.getDouble("C_Fee")
                    );
                }
            }

            // ---------- Module Table ----------
            System.out.println("\n---- Module Table ----");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM Module")) {

                while (rs.next()) {
                    System.out.println(
                            "MCode: " + rs.getString("Mcode") +
                                    ", Name: " + rs.getString("Mname") +
                                    ", Description: " + rs.getString("M_Description") +
                                    ", Credits: " + rs.getInt("NoOfCredits")
                    );
                }
            }

            // ---------- Offers Table ----------
            System.out.println("\n---- Offers Table ----");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM Offers")) {

                while (rs.next()) {
                    System.out.println(
                            "CID: " + rs.getString("cid") +
                                    ", MCode: " + rs.getString("Mcode") +
                                    ", Accadamic Year: " + rs.getString("Accadamic_Year") +
                                    ", Semester: " + rs.getInt("Semester")
                    );
                }
            }

        } catch (SQLException e) {
            System.out.println("❌ Connection failed: " + e.getMessage());
        }
    }
}
