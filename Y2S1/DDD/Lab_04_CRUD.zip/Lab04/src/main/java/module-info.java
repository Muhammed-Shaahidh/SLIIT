module com.lab04 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.lab04 to javafx.fxml;
    exports com.lab04;
}