# Exercise

#Question 01

setwd("C:\\Users\\it24610823\\Desktop\\PS_IT24610823\\Lab06")

# i. What is the distribution of X?
#   -Binomial Distribution (n = 50, p = 0.85)

# ii. What is the probability that at least 47 students passed the test?
pbinom(47, 50, 0.85, lower.tail = FALSE)

#Question 02

# i. What is the random variable (X) for the problem?
#   -No of Customer calls in one hour

# ii. What is the distribution of X?
#   -Poisson Distribution (Lemda = 12)

# iii. What is the probability that exactly 15 calls are received in an hour?
dpois(15, 12)
