setwd("C:\\Users\\Shaa\\OneDrive\\Desktop\\SLIIT\\Sem 03\\PS\\Lab 08")
data <- read.table("Data - Lab 8.txt", header=TRUE)
fix(data)
attach(data)

#1. Calculate the population mean and population standard deviation of the laptop bag weights.
pop_mean <- mean(Nicotine)
pop_sd <- sd(Nicotine)


#2. Draw 25 random samples of size 6 (with replacement) and calculate the sample mean and sample standard deviation for each sample
samples <- c()
n <- c()

for(i in 1:25) {
  s <- sample(Nicotine, 6, replace=TRUE)
  samples <- cbind(samples, s)
  n <- c(n, paste('s', i))
}
colnames(samples) <- n
#3. Calculate the mean and standard deviation of the 25 sample means and state the relationship of them with true mean and true standard deviation.
s_means <- apply(samples, 2, mean)
s_sds <- apply(samples, 2, sd)

mean_sample_means <- mean(s_means)
sd_sample_means <- sd(s_means)

pop_mean
