#1)
setwd("C:\\Users\\Shaa\\OneDrive\\Desktop\\SLIIT\\Sem 03\\PS\\Lab 05")
Delivery_Times<-read.table("Exercise - Lab 05.txt", header= TRUE, sep = "")
fix((Delivery_Times)
attach((Delivery_Times)    

#2)
names(Delivery_Times)<-c("X1")
attach(Delivery_Times)
hist(X1,main="Delivery Times")
histogram<-hist(X1,main="Histogram for Delivery times",breaks =seq(20,70,length=10),right=TRUE)

#4)
# Assuming you already created the histogram
breaks <- seq(20, 70, by = (70-20)/9)  # Create 9 intervals
hist_data <- hist(Delivery_Times$X1, breaks = breaks, right = FALSE, plot = FALSE)

# Extract frequency and midpoints
freq <- hist_data$counts
mid <- hist_data$mids

# Plot frequency polygon
plot(mid, freq, type = "l", main = "Frequency Polygon for Delivery Times",
     xlab = "Delivery Time", ylab = "Frequency", ylim = c(0, max(freq)))

