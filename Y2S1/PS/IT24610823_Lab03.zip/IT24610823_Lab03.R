01.
EXdata<-read.csv("Exercise.csv")
EXdata
fix(EXdata)
names(EXdata)<-c("Age","Gender","Accommodation")
EXdata

EXdata$Gender<-factor(EXdata$Gender,c(1,2),c("Male","Female"))
EXdata$Accommodation<-factor(EXdata$Accommodation,c(1,2,3),c("Home","Boarded","Lodging"))
attach(EXdata)


student_data<-data.frame(EXdata)
student_data

02.# Summary statistics for Age (X1)
summary(student_data$X1)

# Histogram for Age (X1)
hist(student_data$X1,
     main = "Histogram of Age",
     xlab = "Age",
     col = "lightblue",
     border = "black")

03.# Frequency table for Gender (X2)
table(student_data$X2)

# Bar chart for Gender (X2)
barplot(table(student_data$X2),
        main = "Gender Distribution",
        xlab = "Gender (1 = Male, 2 = Female)",
        col = c("skyblue", "pink"))

04.# Boxplot to analyze Age (X1) by Accommodation type (X3)
boxplot(X1 ~ X3, data = student_data,
        main = "Age by Accommodation Type",
        xlab = "Accommodation Type (1 = Home, 2 = Boarded, 3 = Lodging)",
        ylab = "Age",
        col = c("lightgreen", "orange", "lightblue"))