##LabSheet 10
setwd("C:/Users/Shaa/OneDrive/Desktop/SLIIT/Sem 03/PS/Lab 10")

##Question 01
#Part 1
#Here, the shop owner claims that an equal number of customers come into his shop each weekday.
#That means probability of customer arriving on each day would be 0.2.
#To test this claim we need to conduct goodness of fit test which is a chi-squared test.
#So that null hypothesis will be probability that customers arriving on each day will be 0.2.
#Alternative hypothesis will be at least one weekday exists such that probability of customer
#arriving will be different from 0.2.
#To conduct the test observed counts will be stored into a variable called "observed"
#And probabilities for each day will be stored into another variable called "prob"
observed <- c(55, 62, 43, 46, 50)
prob <- c(.2, .2, .2, .2, .2)
#To conduct the test "chisq.test" command will be used as follows.
chisq.test(x=observed, p=prob)


#Part 2
#Consider 5% level of significance for the test.
#Rejection Region: If the p value for the test is less than 0.05,
#reject the null hypothesis at 5% level of significance.
#P value for the test got as 0.351.
#Conclusion: Since the p value (0.351) is greater than 0.05, do not reject null hypothesis at 5%
#level of significance. Therefore we can conclude that probability that customers arriving on
#each day will be same which is 0.2.



##Question 02
#Part 1
#First needs to set the path where data set exists as follows.
file_path <- "C:/Users/Shaa/OneDrive/Desktop/SLIIT/Sem 03/PS/Lab 10/Data.csv"
#Then, "read. delim" command will be used to reads the file which is in a table format
#and creates a data frame from it, with cases corresponding to lines and variables to fields.
housetasks <- read.delim(file_path, row.names = 1)
housetasks

#Exercise

#i. State the Null and Alternative Hypotheses
#H₀ (Null Hypothesis): Customers choose all four snack types (A, B, C, and D) with equal probability.
#H₁ (Alternative Hypothesis): Customers do not choose all four snack types with equal probability.


#ii. Perform a suitable Chi-Square test to test the null hypothesis
# Snack purchase data
snack_counts <- c(120, 95, 85, 100)
# Perform Chi-square Goodness of Fit Test
chisq.test(snack_counts)

#iii. Give your conclusions based on the results
#Based on the Chi-Square test results, the p-value = 0.08947, 
#which is greater than the significance level of 0.05. 
#Therefore, we fail to reject the null hypothesis.
